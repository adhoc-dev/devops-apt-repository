#!/bin/bash

echo "Running adhocTestPkg test script"
