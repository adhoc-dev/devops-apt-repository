#!/bin/bash
#
# Script automágico para trabajar con la nueva infraestructura (Rancher2.x + Kubernetes en GCP)
# Inspirado en código de https://github.com/azacchino
# Repositorio: https://github.com/adhoc-dev/sysadmin-tools/blob/main/rke_byadhoc.sh

declare -a COMMANDS=(bash cluster connect context default describe edit gcp helmlog help history joblog logs logs2 pg redeploy reg scale sleep tunnel undo wake analyze dev update version)
declare -a COMMANDS_NEED_DB=(bash connect context default describe edit gcp help history joblog logs logs2 pg redeploy reg scale sleep tunnel undo wake analyze dev)
RANCHER_CMD="rancher2"
KUBECTL_CMD="$RANCHER_CMD kubectl"
SCRIPT_DIR=$(dirname "$(realpath "$0")")

__get_r2_curr_cluster(){
    local config_path="$HOME/.rancher/cli2.json"
    if [[ ! -f "$config_path" ]]; then
        return
    fi
    local current_cluster=$(jq '.CurrentServer' $config_path)
    local current_cluster_id=\"$(jq -c ".Servers.${current_cluster}.project" $config_path | tr -d \" | cut -d':' -f1)\"
    R2_CURR_CLUSTER=$(jq ".Servers.${current_cluster}.kubeConfigs | to_entries[] | select(.key | contains("$current_cluster_id")) | .value.\"current-context\"" $config_path | tr -d \")
    echo $R2_CURR_CLUSTER
}

__get_r2_curr_region(){
    local cluster=$1
    local script_dir=$(dirname "$(realpath "${BASH_SOURCE[0]}")")
    echo $(jq ".default[\"$cluster\"].region" "$script_dir/rancherClusters.json" | tr -d \")
}

__get_r2_curr_project(){
    local cluster=$1
    local script_dir=$(dirname "$(realpath "${BASH_SOURCE[0]}")")
    echo $(jq ".default[\"$cluster\"].project" "$script_dir/rancherClusters.json" | tr -d \")
}


# Bash Completion

if [[ -n $COMP_LINE ]]; then
    # $1 is the name of the command whose arguments are being completed
    # $2 is the word being completed,
    # $3 is the word preceding the word being completed on the current command line

    # Autocomplete command
    if [[ $1 == "$3" ]]; then
      for c in "${COMMANDS[@]}"; do
        [[ ${c:0:${#2}} == "${2,,}" ]] && echo "$c"
      done
      exit
    fi

    # Autocomplete db
    if [[ " ${COMMANDS_NEED_DB[*]} " == *" $3 "* ]]; then
      R2_CURR_CLUSTER=$(__get_r2_curr_cluster)
      CACHE_DIRR="/home/$USER/.cache/adhoc/r2"
      mkdir -p $CACHE_DIRR
      NS_CACHE_FILE="$CACHE_DIRR/${R2_CURR_CLUSTER}.ns.cache"
      # 3600 -> 1h; 86400 -> 24H
      if [[ ! -f "$NS_CACHE_FILE" ]] || [[ $(( $(date +%s) - $(stat -c %Y "$NS_CACHE_FILE") )) -gt 86400 ]]; then
        $KUBECTL_CMD get ns -o custom-columns=:metadata.name --no-headers 2>/dev/null > $NS_CACHE_FILE
      fi

      compgen -W "$(cat $NS_CACHE_FILE 2>/dev/null )" -- "$2"
    fi

    if [[ $3 == "cluster" ]]; then
        CLUSTERS=$(jq '.Servers.rancherDefault.kubeConfigs | to_entries[] | .value."current-context" ' $HOME/.rancher/cli2.json | tr -d \")
        compgen -W "$CLUSTERS" -- "$2"
    fi

    exit
fi

# Commands

r2_help () {
    echo "R2, el nuevo comando para trabajar con Rancher2 y Kubernetes by Adhoc! 🚀"
    echo "====================="
    echo "🤖 Lista de comandos:"
    echo "====================="
    echo "- ANALYZE: Descarga los logs de un deploy (por defecto 3000 líneas) y los analiza con el script Python odoo_log_analyser.py. Uso: \$ r2 analyze test-odoo-23-12-1 3000"
    echo "- BASH: Patchea el workload aplicando el comando bash y desactivando healthchecks. Uso: \$ r2 bash test-gastrotex-30-08-1 (ver \$ r2 undo)"
    echo "- CLUSTER [DevOps]: cambia de contexto (adhocprod) en caso de tener permisos. Uso: \$ r2 cluster adhocprod"
    echo "- CONNECT: Acceder con bash a una base. Uso: \$ r2 connect test-adhoc-31-12-1"
    echo "- CONTEXT: cambia de contexto (adhocprod) en caso de tener permisos y configuración multicluster. Uso: \$ r2 context adhocprod"
    echo "- DEFAULT: Cambia el contexto actual al namespace de la base de datos. Uso: \$ r2 default test-adhoc-31-12-1"
    echo "- DESCRIBE: Muestra detalles de un recurso o grupo. Uso: \$ r2 describe cotesma"
    echo "- DEV: Cambia la imagen de Docker para tener disponibles las herramientas dev y aplica sleep (historial git, pre-commit, etc.). Uso: \$ r2 dev test-boggio-28-03-1"
    echo "- EDIT: Para editar el deployment con nano (y cambiar parámetros del chart evitando usar RancherUI). Uso: \$ r2 edit test-cotesma-28-03-1"
    echo "- GCP: URL para acceder al workload desde la consola de GCP (DevOps). Uso: \$ r2 gcp symmetria"
    echo "- LOGS: Para ver los logs activos de una base (admite parámetros, ver \$ kubectl logs --help). Uso: \$ r2 logs adhoc [--tail=50] [--follow]"
    echo "- PG: Se conecta al pod directamente ejecutando pg_activity, para analizar queries. Uso: \$ r2 pg test-demo-retail-22-07-1"
    echo "- REDEPLOY: Apaga y reinicia cada contenedor del deployment, no hay downtime ni reinicia valores del workload (rolling restart). Uso: \$ r2 redeploy test-demo-retail-22-07-1"
    echo "- REG: URL para acceder a los logs históricos desde GCP. Uso: \$ r2 reg perfit"
    echo "- SCALE: para modificar el scale de un deploy (más / menos pods, para hacer odoo-fix, etc.). Uso: \$ r2 scale test-base-01-09-1 3"
    echo "- SLEEP: Patchea el workload aplicando el comando sleep infinity y desactivando healthchecks.  Uso: \$ r2 sleep test-gastrotex-30-08-1 (ver \$ r2 undo)"
    echo "- UNDO: roll back a versión anterior del deployment. Uso: \$ r2 undo test-gastrotex-30-08-1"
    echo "- WAKE: a veces el undo no funciona, fixeamos el deploy eliminando el comando (sin health checks). Uso: \$ r2 wake test-gastrotex-30-08-1"
    echo "- UPDATE: Actualiza el script r2.sh. Uso: \$ r2 update"
    echo "- JOBLOG: Para ver los log del job activo (admite parámetros, ver \$ kubectl logs --help). Uso: \$ r2 logs adhoc [--tail=50] [--follow]"
}

r2_version () {
    echo "Version 0.0.2"
}


r2_connect () {
    db=$1
    __exec_it_command_odoo "$db" "bash"
}

r2_context () {
    kubectl config use-context $1
}

r2_joblog () {
    db=$1
    shift
    $KUBECTL_CMD logs -n $db --selector job-name "$@"
}

r2_logs2 () {
    db=$1
    shift
    __colorize_logs () {
        echo "$1" | sed -E 's/ - - \[[^]]+\]//g; s/(ERROR)/\x1b[31m\1\x1b[0m/g; s/(WARNING)/\x1b[33m\1\x1b[0m/g; s/(INFO)/\x1b[32m\1\x1b[0m/g'
    }
    $KUBECTL_CMD logs -n $db --selector adhoc.ar/app-name=odoo -c adhoc-odoo "$@" | while IFS= read -r line; do
        # si el primer caracter es '{' o '[', entonces es un JSON
        if [[ $line == \{* ]]; then
            parsed=$(echo "$line" | jq -R 'fromjson?' 2>/dev/null)
            # echo "Parsed: $parsed"
            if [ "$parsed" = "null" ] || [ -z "$parsed" ]; then
                __colorize_logs $line
            else
                # Si el JSON tiene un campo 'perf_info', lo mostramos con color
                # Si el .name es 'werkzeug' debemos limpiar el .menssage de los timestamps
                jq -r '

                  def showPerf:
                    if (.perf_info|length) > 0 then " \u001b[38;5;37m" + .perf_info + "\u001b[0m" else "" end;

                  def cleanMessage:
                    if (.name == "werkzeug") then
                      .message | gsub(" - - \\[[^\\]]+\\]"; "")
                    else
                      .message
                    end;

                  def colorizeLevel:
                    if .levelname=="ERROR" then "\u001b[31m[\(.levelname)]\u001b[0m"
                    elif .levelname=="WARNING" then "\u001b[33m[\(.levelname)]\u001b[0m"
                    else "\u001b[32m[\(.levelname)]\u001b[0m" end;

                  "\(.asctime) " + colorizeLevel + " \(.name): " + cleanMessage + showPerf

                  ' <<< "$parsed"
            fi
        else
            __colorize_logs $line
        fi
    done
}

r2_logs () {
    db=$1
    shift
    $KUBECTL_CMD logs -n $db --selector adhoc.ar/app-name=odoo -c adhoc-odoo "$@" | while IFS= read -r line; do
        if echo "$line" | grep -qE '^\{.*\}$'; then
            parsed=$(echo "$line" | jq -R 'fromjson?' 2>/dev/null)
            if [ "$parsed" = "null" ] || [ -z "$parsed" ]; then
                echo "$line"
            else
                echo "$parsed" | jq -r '
                  def colorizePerf:
                    gsub("([0-9]+\\s+[0-9]+\\s+[0-9.]+)$"; "\u001b[38;5;37m\\1\u001b[0m");
                  def cleanMessage: .message | gsub(" - - \\[[^\\]]+\\]"; "");
                  def showPerf:
                    if (.perf_info|length) > 0 then " \u001b[38;5;37m" + .perf_info + "\u001b[0m" else "" end;
                  if .levelname=="ERROR" then
                    "\(.asctime) \u001b[31m[\(.levelname)]\u001b[0m \(.name): " +
                      (if (.perf_info|length) > 0 then cleanMessage + showPerf
                       else (cleanMessage | colorizePerf) end)
                  elif .levelname=="WARNING" then
                    "\(.asctime) \u001b[33m[\(.levelname)]\u001b[0m \(.name): " +
                      (if (.perf_info|length) > 0 then cleanMessage + showPerf
                       else (cleanMessage | colorizePerf) end)
                  else
                    "\(.asctime) \u001b[32m[\(.levelname)]\u001b[0m \(.name): " +
                      (if (.perf_info|length) > 0 then cleanMessage + showPerf
                       else (cleanMessage | colorizePerf) end)
                  end'
            fi
        else
            echo "$line" | sed -E 's/ - - \[[^]]+\]//g; s/(ERROR)/\x1b[31m\1\x1b[0m/g; s/(WARNING)/\x1b[33m\1\x1b[0m/g; s/(INFO)/\x1b[32m\1\x1b[0m/g'
        fi
    done
}

r2_reg () {
    R2_CURR_CLUSTER=$(__get_r2_curr_cluster)
    R2_CURR_REGION=$(__get_r2_curr_region $R2_CURR_CLUSTER)
    R2_CURR_PROJECT=$(__get_r2_curr_project $R2_CURR_CLUSTER)
    echo "https://console.cloud.google.com/logs/query;query=resource.type%3D%22k8s_container%22%0Aresource.labels.namespace_name%3D%22$1%22?project=$R2_CURR_PROJECT"
}

r2_redeploy () {
    $KUBECTL_CMD rollout restart deployment $1-adhoc-odoo -n $1
}

r2_history () {
    $KUBECTL_CMD rollout history deployment $1-adhoc-odoo -n $1
}

r2_bash () {
    $KUBECTL_CMD patch deployment $1-adhoc-odoo -n $1 --patch '{"metadata": {"annotations": {"adhoc.ar/dev-name": "'"$USER"'", "adhoc.ar/dev-r2cmd": "bash", "kubernetes.io/change-cause": "r2 bash by '"$USER"'"}}, "spec": {"template": {"spec": {"containers": [{"name": "adhoc-odoo","args": ["/bin/sh","-c","bash"],"livenessProbe": null,"readinessProbe": null,"startupProbe": null}]}}}}'
}

r2_sleep () {
    $KUBECTL_CMD patch deployment $1-adhoc-odoo -n $1 --patch '{"metadata": {"annotations": {"adhoc.ar/dev-name": "'"$USER"'", "adhoc.ar/dev-r2cmd": "sleep", "kubernetes.io/change-cause": "r2 sleep by '"$USER"'"}}, "spec": {"template": {"spec": {"containers": [{"name": "adhoc-odoo","args": ["/bin/sh","-c","sleep infinity"],"livenessProbe": null,"readinessProbe": null,"startupProbe": null}]}}}}'
}

r2_wake () {
    $KUBECTL_CMD patch deployment $1-adhoc-odoo -n $1 --patch '{"metadata": {"annotations": {"adhoc.ar/dev-name": "'"$USER"'", "adhoc.ar/dev-r2cmd": "wake", "kubernetes.io/change-cause": "r2 wake by '"$USER"'"}}, "spec": {"template": {"spec": {"containers": [{"name": "adhoc-odoo","args": [],"livenessProbe": null,"readinessProbe": null,"startupProbe": null}]}}}}'
}

r2_undo () {
    $KUBECTL_CMD rollout undo deployment $1-adhoc-odoo -n $1
}

r2_pg () {
  db=$1
  __exec_it_command_odoo "$db" "pg_activity"
}

r2_edit () {
    KUBE_EDITOR="nano" $KUBECTL_CMD edit -n $1 deploy/$1-adhoc-odoo
}

r2_dev () {
  deploy="$1-adhoc-odoo";
  ns="$1";
  current_image=$($KUBECTL_CMD get deployment "$deploy" -n "$ns" -o=jsonpath="{.spec.template.spec.containers[0].image}");
  # Check if the image is already in dev mode
  if [[ "$current_image" == *".dev" ]]; then
      echo "The deployment is already in dev mode."
  else
      current_image="${current_image}.dev";
  fi
  $KUBECTL_CMD patch deployment $deploy -n $ns --patch '{"metadata": {"annotations": {"adhoc.ar/dev-name": "'"$USER"'", "adhoc.ar/dev-r2cmd": "dev", "kubernetes.io/change-cause": "r2 dev by '"$USER"'"}}, "spec": {"template": {"spec": {"containers": [{"name": "adhoc-odoo", "image": "'"$current_image"'", "args": ["/bin/sh","-c","sleep infinity"],"livenessProbe": null,"readinessProbe": null,"startupProbe": null}]}}}}'
}

##########
# DevOps #
##########
r2_cluster () {
    local desired_cluster=$1
    local config_path="$HOME/.rancher/cli2.json"
    if [[ ! -f "$config_path" ]]; then
        return
    fi

    local CLUSTERS=$(jq '.Servers.rancherDefault.kubeConfigs // {} | to_entries[] | .value."current-context" ' $config_path | tr -d \")
    # Verificar si el cluster requerido existe
    if ! echo -e "$CLUSTERS" | grep -q "^$desired_cluster$"; then
        echo "Cluster not found or you don't have access to it."
        exit -1
    fi

    local CURR_DATE=$(date +%s )
    local KUBE_PATH="$HOME/.kube/config"
    touch $KUBE_PATH
    cp $KUBE_PATH $HOME/.kube/${CURR_DATE}.config.back
    $RANCHER_CMD cluster kf $desired_cluster > $KUBE_PATH
    DEFAULT_PROJECT=$(false | $RANCHER_CMD context switch | grep Default | grep $desired_cluster | awk '{print $3}')
    $RANCHER_CMD context switch $DEFAULT_PROJECT
}

r2_describe () {
    $KUBECTL_CMD describe -n $1 deploy/$1-adhoc-odoo
}

r2_gcp () {
    R2_CURR_CLUSTER=$(__get_r2_curr_cluster)
    R2_CURR_REGION=$(__get_r2_curr_region $R2_CURR_CLUSTER)
    R2_CURR_PROJECT=$(__get_r2_curr_project $R2_CURR_CLUSTER)
    echo https://console.cloud.google.com/kubernetes/deployment/$R2_CURR_REGION/$R2_CURR_CLUSTER/$1/$1-adhoc-odoo/overview?project=$R2_CURR_PROJECT
}

r2_scale () {
    __check_is_positive_int $2
    $KUBECTL_CMD patch deployment $1-adhoc-odoo -n $1 --patch '{"spec": { "replicas": '"$2"' }, "metadata": {"annotations": {"adhoc.ar/dev-name": "'"$USER"'", "adhoc.ar/dev-r2cmd": "scale", "kubernetes.io/change-cause": "r2 scale by '"$USER"'"}}}'
}

r2_tunnel () {
    local db="$1"
    PASS=$($KUBECTL_CMD get cm/$db-adhoc-odoo-common-envs -n "$db" -o json | jq -r '.data.PGPASSWORD')
    $KUBECTL_CMD port-forward -n "$db" svc/$db-pg-rw :5432 &
    TUNNEL_PID=$!
    echo "Túnel creado con PID $TUNNEL_PID. Accede a la base de datos user: odoo pass: $PASS"
    # Close the tunnel on exit
    trap "kill $TUNNEL_PID; echo 'Tunnel closed'; exit" INT TERM
    wait $TUNNEL_PID
}

r2_analyze () {

    local analyser_file="$SCRIPT_DIR/../../odoo_log_analyser/odoo_log_analyser.py"
    if [[ ! -f "$analyser_file" ]]; then
        echo "The analyzer is missing, please clone odoo_log_analyser"
        echo -e "\tcd $SCRIPT_DIR/../../ && git clone -b fixes-devops https://github.com/adhoc-dev/odoo_log_analyser.git && cd -"
        exit -1
    fi

    # 1) Tomar los parámetros
    local db=$1           # Nombre del deployment / namespace
    local lines=${2:-3000}        # Cantidad de líneas del log (por defecto 3000)
    __check_is_positive_int $lines
    local threshold=${3:-0.03}    # Nuevo: threshold (por defecto, p. ej. 0.03)
    __check_is_positive_float $threshold
    local tmp_log="/tmp/${db}_r2_analyze.log"

    echo "Descargando últimos $lines registros del log para el deploy '$db'..."
    $KUBECTL_CMD logs -n "$db" --selector app.kubernetes.io/instance="$db" --tail="$lines" > "$tmp_log"

    if [[ $? -ne 0 ]]; then
        echo "Error: no se pudieron descargar los logs. Verifica el namespace o el nombre del deploy."
        exit -1
    fi

    echo "Log descargado en $tmp_log"
    echo "Ejecutando odoo_log_analyser.py con threshold=$threshold ..."
    python3 $analyser_file --threshold "$threshold" --include-no-db -vr "$tmp_log"
    rm -rf $tmp_log
}

r2_update () {
    echo "Actualizando team tools..."
    cd $SCRIPT_DIR/../
    local STASH_APPLIED=1
    if ! git diff --quiet; then
        git stash
        STASH_APPLIED=$?
    fi
    git pull
    if [[ "$STASH_APPLIED" -eq 0 ]]; then
        git stash pop | true
    fi
    cd -
    echo "Listo!"

    echo "Actualizando Rancher Cli..."
    CURRENT_VERSION=$(rancher -v | awk '{print $3}' | tr -d 'v')
    LATEST_VERSION=$(curl -s https://api.github.com/repos/rancher/cli/releases/latest | jq -r '.tag_name' | tr -d 'v')
    DOWNLOAD_URL=$(curl -s https://api.github.com/repos/rancher/cli/releases/latest | jq -r '.assets[] | select(.name | test("rancher-linux-amd64-v'${LATEST_VERSION}'.tar.gz$")) | .browser_download_url')
    if [[ "$CURRENT_VERSION" != "$LATEST_VERSION" ]]; then
        echo "Descargando Rancher Cli $LATEST_VERSION..."
        cd /tmp/
        wget -q -O rancher.tar.gz $DOWNLOAD_URL
        tar -xzf rancher.tar.gz 2>/dev/null
        sudo mv rancher-v$LATEST_VERSION/rancher /usr/local/bin/rancher
        rm -rf rancher.tar.gz rancher-v$LATEST_VERSION
        cd -
        echo "Rancher Cli actualizado a la versión $(rancher -v)"
    else
        echo "Rancher Cli ya está actualizado a la última versión"
    fi
}

r2_helmlog () {
    $KUBECTL_CMD logs -n devops --selector job-name "$@"
}

r2_default () {
    local db="$1"
    # Check if ns exists
    if ! $KUBECTL_CMD get ns "$db" &>/dev/null; then
        echo "Namespace '$db' no existe."
        return 1
    fi
    kubectl config set-context --current --namespace=$db
}

# Internals

__exec_it_command_odoo (){
  local db="$1"
  local cmd="$2"
  POD_NAME=$($KUBECTL_CMD get pods -n "$db" --selector adhoc.ar/app-name=odoo --no-headers  | grep -m1 "adhoc-odoo" | awk '{print $1}')
  if [ -z "$POD_NAME" ]; then
      echo "No se encontró ningún pod con 'adhoc-odoo' en el namespace $1"
      return 1
  fi
  $KUBECTL_CMD exec -ti -n "$1" -c adhoc-odoo "$POD_NAME" -- $cmd
}

__has_at_least_one_arg (){
  if [[ $# -lt 1 ]]; then
      echo "Debe especificar al menos la base de datos"
      exit -1;
  fi
}

__check_is_positive_int (){
  if [[ ! "$1" =~ ^[0-9]+$ ]]; then
      echo "El argumento NO es un número entero."
      exit -1
  fi
}

__check_is_positive_float (){
  if [[ ! "$1" =~ ^[0-9]+([.][0-9]+)?$ ]] || (( $(echo "$1 <= 0" | bc -l) )); then
      echo "El argumento NO es un número flotante positivo."
      exit -1
  fi
}

# Start point

declare cmd="$1"; shift

if [[ " ${COMMANDS[*]} " != *" $cmd "* ]]; then
  r2_help
  exit 1
fi

db=""
if [[ " ${COMMANDS_NEED_DB[*]} " == *" $cmd "* ]]; then
    # Si no se especifica el nombre de la base de datos, se obtiene del contexto actual
    # los dos casos son, cuando no hay argumentos o cuando el primer argumento es un flag
    if [[ $# -lt 1 ]] || [[ "$1" == -* ]] || [[ "$1" == [0-9] ]]; then
        db=$(kubectl config view --minify | grep namespace: | awk '{print $2}')
        echo "NS: $db"
        if [[ -z "$db" ]]; then
            echo "No se especificó el nombre de la base de datos y no se pudo obtener del contexto actual."
            exit 1
        fi
    else
        db=$1
        shift
    fi
fi

"r2_$cmd" $db "$@" && exit $?
